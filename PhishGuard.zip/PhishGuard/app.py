from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import pickle
import numpy as np
import joblib  # Import joblib here

app = Flask(__name__)
CORS(app)

# Load the machine learning model
def load_model():
    with open('trained_model.pkl', 'rb') as file:
        # Load the model using pickle
        try:
            model = pickle.load(file)
            # Print the scikit-learn version used for training
            print("Model trained with scikit-learn version:", model._sklearn_version)
        except ValueError:
            # If there is a ValueError, try loading with joblib
            file.seek(0)
            model = joblib.load(file)
            # Print the scikit-learn version used for training
            print("Model trained with scikit-learn version:", model._sklearn_version)
        except Exception as e:
            print("Error loading model with pickle:", e)
            try:
                file.seek(0)
                model = pickle.load(file, encoding='latin1')
                # Print the scikit-learn version used for training
                print("Model trained with scikit-learn version:", model._sklearn_version)
            except Exception as e:
                print("Error loading model with encoding latin1:", e)
                return None
        return model

# Home route
@app.route('/')
def home():
    return render_template('index.html')

# Prediction route
@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get data from POST request
        data = request.get_json()
        link = data['link']

        # Load the model
        model = load_model()

        # Perform prediction
        prediction = model.predict([link])
        confidence_score = model.predict_proba([link])[:, 1]
        ssl_expiry_days = 30  # Placeholder value, replace with actual SSL expiry days
        whois_info = {}  # Placeholder value, replace with actual WHOIS information
        feature_importance = model.feature_importances_.tolist()

        # Prepare response
        response = {
            'prediction': int(prediction[0]),
            'confidence_score': float(confidence_score[0]),
            'ssl_expiry_days': ssl_expiry_days,
            'whois_info': whois_info,
            'feature_importance': feature_importance
        }

        return jsonify(response)

    except Exception as e:
        # Handle exceptions
        print("Error:", e)
        return jsonify({'error': 'An error occurred during prediction.'}), 500

if __name__ == '__main__':
    app.run(debug=True)
