function checkLink() {
    const linkInput = document.getElementById('linkInput').value;
    const resultBox = document.getElementById('resultBox');

    fetch('/predict', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ 'link': linkInput })
    })
    .then(response => response.json())
    .then(data => {
        const result = `
            <h2>Results</h2>
            <p><strong>Classification Result:</strong> ${data.prediction === 1 ? 'Phishing' : 'Genuine'}</p>
            <p><strong>Confidence Score:</strong> ${data.confidence_score}</p>
            <p><strong>SSL Expiry Days:</strong> ${data.ssl_expiry_days}</p>
            <p><strong>WHOIS Information:</strong> ${JSON.stringify(data.whois_info)}</p>
            <p><strong>Feature Importance:</strong></p>
            <ul>
                ${data.feature_importance.map(feature => `<li>${feature}</li>`).join('')}
            </ul>
        `;
        resultBox.innerHTML = result;
        scrollToSection('result');
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    section.scrollIntoView({ behavior: 'smooth' });
}
